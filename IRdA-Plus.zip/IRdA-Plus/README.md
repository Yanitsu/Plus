# IRdA+ (InputRedirection client para Android)

Versão reescrita do IRdA (MarcusD / Sono): mesma comunicação com o 3DS (UDP, porta 4950,
pacote de 20 bytes), com interface nova, tradução EN/PT-BR e **macros em ZL/ZR (e qualquer botão)**.

## Como compilar
- **Android Studio**: File ▸ Open ▸ pasta `IRdA-Plus` ▸ Build ▸ Build APK(s).
- **Sem instalar nada**: suba a pasta num repositório do GitHub; o workflow em
  `.github/workflows/build.yml` gera o APK em *Actions ▸ Artifacts*.

## Macros
Toque em **Adicionar macro**. Escolha o botão de disparo (ZL, ZR, L, A…), o modo e a sequência.

Sintaxe: `BOTÃO:ms`, `A+B:ms` (juntos), `wait:ms` (pausa). `#` inicia comentário.

| Modo | Efeito |
|---|---|
| Uma vez a cada toque | roda a sequência uma vez |
| Repetir enquanto segurar | loop até soltar (turbo) |
| Liga / desliga | um toque liga o loop, outro desliga |

Exemplos: `A:40 wait:40` (turbo A), `ZR+A:300` (ZR+A juntos por 300 ms), `X:50 wait:80 Y:50`.
Por padrão o botão de disparo físico é substituído pela macro; marque
“Enviar também o botão original” para manter os dois.

## Gatilhos analógicos
Ligados por padrão: LT/RT (ou BRAKE/GAS) acima do limite ajustável viram ZL/ZR, e também
disparam as macros.

## Idioma
Segue o sistema; pode ser trocado em Configurações. Para adicionar um idioma, copie
`res/values/strings.xml` para `res/values-xx/strings.xml`.

## Testes do núcleo (sem Android)
`tests/CoreTest.java` valida pacote, parser, motor de macros e envio UDP:
```
javac -d out app/src/main/java/Sono/IRDa/core/*.java tests/CoreTest.java && java -cp out CoreTest
```
