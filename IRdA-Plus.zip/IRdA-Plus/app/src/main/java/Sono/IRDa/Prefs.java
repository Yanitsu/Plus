package Sono.IRDa;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import android.view.MotionEvent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import Sono.IRDa.core.Key;
import Sono.IRDa.core.Macro;
import Sono.IRDa.core.MacroParser;

/** Preferências persistentes (com migração do app original, arquivo "cal"). */
public final class Prefs {
    public static final String FILE = "irda_plus";
    public static final int AXES = 4; // CPad X, CPad Y, CStick X, CStick Y

    private static final int[] DEFAULT_AXIS = {
            MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ};
    /** Multiplicador para que "direita" e "cima" sejam positivos (Android: Y cresce para baixo). */
    private static final int[] DEFAULT_SIGN = {1, -1, 1, -1};

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        if (!sp.getBoolean("init", false)) {
            resetBindings();
            migrateLegacy(c);
            sp.edit().putBoolean("init", true).apply();
        }
    }

    static String language(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("lang", "");
    }

    // ---------- bindings ----------
    private static int defaultKeyCode(Key k) {
        switch (k) {
            // Layout "posicional" Nintendo: botão da direita = A, de baixo = B etc.
            case A: return KeyEvent.KEYCODE_BUTTON_B;
            case B: return KeyEvent.KEYCODE_BUTTON_A;
            case X: return KeyEvent.KEYCODE_BUTTON_Y;
            case Y: return KeyEvent.KEYCODE_BUTTON_X;
            case L: return KeyEvent.KEYCODE_BUTTON_L1;
            case R: return KeyEvent.KEYCODE_BUTTON_R1;
            case ZL: return KeyEvent.KEYCODE_BUTTON_L2;
            case ZR: return KeyEvent.KEYCODE_BUTTON_R2;
            case START: return KeyEvent.KEYCODE_BUTTON_START;
            case SELECT: return KeyEvent.KEYCODE_BUTTON_SELECT;
            case HOME: return KeyEvent.KEYCODE_BUTTON_MODE;
            case DUP: return KeyEvent.KEYCODE_DPAD_UP;
            case DDOWN: return KeyEvent.KEYCODE_DPAD_DOWN;
            case DLEFT: return KeyEvent.KEYCODE_DPAD_LEFT;
            case DRIGHT: return KeyEvent.KEYCODE_DPAD_RIGHT;
            default: return 0;
        }
    }

    public void resetBindings() {
        SharedPreferences.Editor e = sp.edit();
        for (Key k : Key.values()) e.putInt("k_" + k.name(), defaultKeyCode(k));
        for (int i = 0; i < AXES; i++) {
            e.putInt("ax_" + i, DEFAULT_AXIS[i]);
            e.putInt("axs_" + i, DEFAULT_SIGN[i]);
        }
        e.apply();
    }

    public int getKeyCode(Key k) { return sp.getInt("k_" + k.name(), 0); }
    public void setKeyCode(Key k, int code) { sp.edit().putInt("k_" + k.name(), code).apply(); }

    public int getAxis(int i) { return sp.getInt("ax_" + i, DEFAULT_AXIS[i]); }
    public int getAxisSign(int i) { return sp.getInt("axs_" + i, DEFAULT_SIGN[i]); }
    public void setAxis(int i, int axis, int sign) {
        sp.edit().putInt("ax_" + i, axis).putInt("axs_" + i, sign).apply();
    }

    // ---------- settings ----------
    public String getIp() { return sp.getString("ip", ""); }
    public void setIp(String v) { sp.edit().putString("ip", v).apply(); }
    public boolean autoconnect() { return sp.getBoolean("autoconnect", false); }
    public void setAutoconnect(boolean v) { sp.edit().putBoolean("autoconnect", v).apply(); }
    public boolean noDefault() { return sp.getBoolean("nodefault", true); }
    public void setNoDefault(boolean v) { sp.edit().putBoolean("nodefault", v).apply(); }
    public boolean analogTriggers() { return sp.getBoolean("analog_trig", true); }
    public void setAnalogTriggers(boolean v) { sp.edit().putBoolean("analog_trig", v).apply(); }
    /** 10..95 (%) */
    public int triggerThreshold() { return sp.getInt("trig_thr", 50); }
    public void setTriggerThreshold(int v) { sp.edit().putInt("trig_thr", v).apply(); }
    /** 0..40 (%) */
    public int deadzone() { return sp.getInt("deadzone", 12); }
    public void setDeadzone(int v) { sp.edit().putInt("deadzone", v).apply(); }
    public boolean invertCsX() { return sp.getBoolean("inv_cs_x", false); }
    public void setInvertCsX(boolean v) { sp.edit().putBoolean("inv_cs_x", v).apply(); }
    public boolean invertCsY() { return sp.getBoolean("inv_cs_y", false); }
    public void setInvertCsY(boolean v) { sp.edit().putBoolean("inv_cs_y", v).apply(); }
    public String lang() { return sp.getString("lang", ""); }
    public void setLang(String v) { sp.edit().putString("lang", v).apply(); }

    // ---------- macros ----------
    public List<Macro> loadMacros() {
        List<Macro> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString("macros", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject o = arr.getJSONObject(i);
                    Macro m = new Macro();
                    m.name = o.optString("name", "");
                    Key t = Key.byName(o.optString("trigger", "ZR"));
                    m.trigger = t != null ? t : Key.ZR;
                    try { m.mode = Macro.Mode.valueOf(o.optString("mode", "ONCE")); }
                    catch (IllegalArgumentException ex) { m.mode = Macro.Mode.ONCE; }
                    m.passthrough = o.optBoolean("passthrough", false);
                    m.enabled = o.optBoolean("enabled", true);
                    m.steps = MacroParser.parse(o.optString("steps", ""));
                    out.add(m);
                } catch (MacroParser.ParseException | JSONException ignored) {
                    // ignora macro corrompida
                }
            }
        } catch (JSONException ignored) { }
        return out;
    }

    public void saveMacros(List<Macro> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Macro m : list) {
                JSONObject o = new JSONObject();
                o.put("name", m.name);
                o.put("trigger", m.trigger.name());
                o.put("mode", m.mode.name());
                o.put("passthrough", m.passthrough);
                o.put("enabled", m.enabled);
                o.put("steps", MacroParser.format(m.steps));
                arr.put(o);
            }
        } catch (JSONException ignored) { }
        sp.edit().putString("macros", arr.toString()).apply();
    }

    // ---------- migração do IRdA original ----------
    private void migrateLegacy(Context c) {
        SharedPreferences old = c.getSharedPreferences("cal", Context.MODE_PRIVATE);
        if (old.getAll().isEmpty()) return;
        SharedPreferences.Editor e = sp.edit();
        String ip = old.getString("IP", "");
        if (ip != null && !ip.isEmpty()) e.putString("ip", ip);
        e.putBoolean("autoconnect", old.getBoolean("autoconnect", false));
        e.putBoolean("nodefault", old.getBoolean("nodef", true));
        for (Key k : Key.values()) {
            int code = old.getInt("kcal_" + k.legacy, 0);
            if (code > 0) e.putInt("k_" + k.name(), code);
        }
        e.apply();
        // Eixos antigos usam outro formato; ficam nos padrões e podem ser recalibrados na tela.
    }
}
