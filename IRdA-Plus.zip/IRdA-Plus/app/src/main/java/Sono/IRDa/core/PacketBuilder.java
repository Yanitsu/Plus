package Sono.IRDa.core;

/**
 * Monta o pacote de 20 bytes do InputRedirection (UDP, porta 4950).
 * Layout (descoberto no app original):
 *  0..3   HID (ativo em 0): ~teclas & 0xFFF  (A,B,Select,Start,→,←,↑,↓,R,L,X,Y)
 *  4..7   toque (sem toque = 0x02000000)
 *  8..11  Circle Pad: x12 | y12<<12 (centro 0x800)
 *  12..15 C-Stick/ZL/ZR: [0]=0x81, [1]=ZL?4:0 | ZR?2:0, [2],[3] = eixos girados 45° (centro 0x80)
 *  16..19 interface: bit0=HOME, bit1=POWER
 */
public final class PacketBuilder {
    public static final int SIZE = 20;
    public static final int PORT = 4950;
    private static final double SQRT1_2 = Math.sqrt(0.5);

    private PacketBuilder() {}

    static int clampI(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    static double clampD(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    /** cpx/csx: direita positivo; cpy/csy: cima positivo; faixa [-1,1]. */
    public static void build(byte[] b, int held,
                             float cpx, float cpy, float csx, float csy) {
        int hid = ~held & 0xFFF;
        b[0] = (byte) (hid & 0xFF);
        b[1] = (byte) ((hid >> 8) & 0x0F);
        b[2] = 0;
        b[3] = 0;

        // sem toque
        b[4] = 0; b[5] = 0; b[6] = 0; b[7] = 2;

        int cx = clampI(Math.round(cpx * 2047f), -2047, 2047) + 2048;
        int cy = clampI(Math.round(cpy * 2047f), -2047, 2047) + 2048;
        int cp = (cx & 0xFFF) | ((cy & 0xFFF) << 12);
        b[8] = (byte) (cp & 0xFF);
        b[9] = (byte) ((cp >> 8) & 0xFF);
        b[10] = (byte) ((cp >> 16) & 0xFF);
        b[11] = 0;

        b[12] = (byte) 0x81;
        int zlzr = ((held & Key.ZL.bit()) != 0 ? 4 : 0) | ((held & Key.ZR.bit()) != 0 ? 2 : 0);
        b[13] = (byte) zlzr;
        double x = clampD(csx, -1, 1), y = clampD(csy, -1, 1);
        b[15] = (byte) (int) (clampD((y - x) * SQRT1_2 * 127.0, -127, 127) + 128.0);
        b[14] = (byte) (int) (clampD((y + x) * SQRT1_2 * 127.0, -127, 127) + 128.0);

        b[16] = (byte) (((held & Key.HOME.bit()) != 0 ? 1 : 0) | ((held & Key.POWER.bit()) != 0 ? 2 : 0));
        b[17] = 0; b[18] = 0; b[19] = 0;
    }
}
