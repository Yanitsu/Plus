package Sono.IRDa.core;

/**
 * Estado de entrada compartilhado (thread-safe).
 * Fontes físicas: botões e eixos (gatilhos analógicos/D-pad). Macros entram por "owners".
 * Teclas que têm macro ativa ficam "suprimidas" (não vão direto ao 3DS).
 */
public final class InputState {
    public static final int SRC_BUTTON = 0, SRC_AXIS = 1;
    public static final int MAX_OWNERS = 64;

    public interface KeyListener { void onPhysicalKey(Key k, boolean down); }
    public interface ChangeListener { void onChanged(); }

    private final Object lock = new Object();
    private final int[] src = new int[2];
    private final int[] owners = new int[MAX_OWNERS];
    private int suppressed;
    private float cpx, cpy, csx, csy;
    private volatile KeyListener keyListener;
    private volatile ChangeListener changeListener;

    public void setKeyListener(KeyListener l) { keyListener = l; }
    public void setChangeListener(ChangeListener l) { changeListener = l; }

    private int physicalLocked() { return src[0] | src[1]; }

    public void setSource(int source, Key k, boolean down) {
        boolean before, after, changed;
        synchronized (lock) {
            int old = src[source];
            before = (physicalLocked() & k.bit()) != 0;
            if (down) src[source] |= k.bit(); else src[source] &= ~k.bit();
            after = (physicalLocked() & k.bit()) != 0;
            changed = old != src[source];
        }
        if (!changed) return;
        KeyListener kl = keyListener;
        if (before != after && kl != null) kl.onPhysicalKey(k, after);
        fire();
    }

    public void setSticks(float cpx, float cpy, float csx, float csy) {
        synchronized (lock) {
            if (this.cpx == cpx && this.cpy == cpy && this.csx == csx && this.csy == csy) return;
            this.cpx = cpx; this.cpy = cpy; this.csx = csx; this.csy = csy;
        }
        fire();
    }

    public void setOwnerMask(int owner, int mask) {
        synchronized (lock) { owners[owner] = mask; }
        fire();
    }

    public void setSuppressed(int mask) {
        synchronized (lock) { suppressed = mask; }
        fire();
    }

    /** Solta tudo (usado ao desconectar / perder foco). */
    public void releaseAll() {
        synchronized (lock) {
            src[0] = 0; src[1] = 0;
            cpx = cpy = csx = csy = 0;
        }
        fire();
    }

    public int physicalMask() { synchronized (lock) { return physicalLocked(); } }

    public int effectiveMask() {
        synchronized (lock) {
            int m = 0;
            for (int o : owners) m |= o;
            return (physicalLocked() & ~suppressed) | m;
        }
    }

    /** Preenche o pacote de 20 bytes com o estado atual. */
    public void pack(byte[] out) {
        int held; float a, b, c, d;
        synchronized (lock) {
            int m = 0;
            for (int o : owners) m |= o;
            held = (physicalLocked() & ~suppressed) | m;
            a = cpx; b = cpy; c = csx; d = csy;
        }
        PacketBuilder.build(out, held, a, b, c, d);
    }

    public float[] sticks() { synchronized (lock) { return new float[]{cpx, cpy, csx, csy}; } }

    private void fire() {
        ChangeListener l = changeListener;
        if (l != null) l.onChanged();
    }
}
