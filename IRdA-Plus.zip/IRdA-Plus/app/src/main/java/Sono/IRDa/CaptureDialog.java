package Sono.IRDa;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Diálogo que espera um botão ou um movimento de analógico do controle. */
final class CaptureDialog extends Dialog {
    interface Callback {
        /** Retorne true quando capturou (fecha o diálogo). */
        boolean onKey(KeyEvent e);
        boolean onMotion(MotionEvent e);
    }

    private final Callback cb;

    CaptureDialog(Context c, String title, String message, Callback cb) {
        super(c, R.style.AppDialog);
        this.cb = cb;
        setCanceledOnTouchOutside(false);

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UiText.dp(c, 22);
        box.setPadding(p, p, p, UiText.dp(c, 12));

        TextView t = new TextView(c);
        t.setText(title);
        t.setTextSize(20);
        t.setTextColor(UiText.color(c, R.color.text));
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(t);

        TextView m = new TextView(c);
        m.setText(message);
        m.setTextSize(16);
        m.setTextColor(UiText.color(c, R.color.text_dim));
        m.setPadding(0, UiText.dp(c, 12), 0, UiText.dp(c, 16));
        box.addView(m);

        Button cancel = new Button(c);
        cancel.setText(R.string.capture_cancel);
        cancel.setAllCaps(false);
        cancel.setTextColor(UiText.color(c, R.color.accent));
        cancel.setBackgroundResource(R.drawable.btn_outline);
        cancel.setOnClickListener(v -> dismiss());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UiText.dp(c, 46));
        lp.gravity = Gravity.CENTER;
        box.addView(cancel, lp);

        setContentView(box);
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e);
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0 && cb.onKey(e)) dismiss();
        return true;
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_MOVE && cb.onMotion(e)) dismiss();
        return true;
    }
}
