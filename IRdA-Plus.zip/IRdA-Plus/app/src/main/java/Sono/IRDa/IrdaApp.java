package Sono.IRDa;

import android.app.Application;
import android.content.Context;

public final class IrdaApp extends Application {
    private PadController pad;

    @Override public void onCreate() {
        super.onCreate();
        pad = new PadController(this);
    }

    static PadController pad(Context c) {
        return ((IrdaApp) c.getApplicationContext()).pad;
    }
}
